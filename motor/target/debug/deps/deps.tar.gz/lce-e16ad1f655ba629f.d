/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/lce-e16ad1f655ba629f.d: src/main.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/lce-e16ad1f655ba629f: src/main.rs

src/main.rs:
