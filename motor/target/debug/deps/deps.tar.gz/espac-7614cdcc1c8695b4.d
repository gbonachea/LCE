/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-7614cdcc1c8695b4.d: src/lib.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/libespac-7614cdcc1c8695b4.rlib: src/lib.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/libespac-7614cdcc1c8695b4.rmeta: src/lib.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

src/lib.rs:
src/ast.rs:
src/codegen.rs:
src/lexer.rs:
src/parser.rs:
src/semantica.rs:
src/token.rs:
