/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-924f8e08edfa49bd.d: src/main.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-924f8e08edfa49bd: src/main.rs

src/main.rs:
