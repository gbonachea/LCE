/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/lce-8104f7e56b208ead.d: src/main.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/lce-8104f7e56b208ead: src/main.rs

src/main.rs:
