/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-aaabe96d07bcbf89.d: src/main.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-aaabe96d07bcbf89: src/main.rs

src/main.rs:
