/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/integracion-8ea1d0700b7fe92e.d: tests/integracion.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/integracion-8ea1d0700b7fe92e: tests/integracion.rs

tests/integracion.rs:

# env-dep:CARGO_MANIFEST_DIR=/home/gus/Downloads/Proyect/Lenguaje/motor
