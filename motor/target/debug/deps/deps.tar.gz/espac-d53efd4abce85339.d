/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-d53efd4abce85339.d: src/lib.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-d53efd4abce85339: src/lib.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

src/lib.rs:
src/ast.rs:
src/codegen.rs:
src/lexer.rs:
src/parser.rs:
src/semantica.rs:
src/token.rs:
