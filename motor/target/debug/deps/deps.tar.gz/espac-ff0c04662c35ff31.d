/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-ff0c04662c35ff31.d: src/main.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/espac-ff0c04662c35ff31: src/main.rs src/ast.rs src/codegen.rs src/lexer.rs src/parser.rs src/semantica.rs src/token.rs

src/main.rs:
src/ast.rs:
src/codegen.rs:
src/lexer.rs:
src/parser.rs:
src/semantica.rs:
src/token.rs:
