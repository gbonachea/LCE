/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/integracion-c7109e67d07ce64d.d: tests/integracion.rs

/home/gus/Downloads/Proyect/Lenguaje/motor/target/debug/deps/integracion-c7109e67d07ce64d: tests/integracion.rs

tests/integracion.rs:

# env-dep:CARGO_MANIFEST_DIR=/home/gus/Downloads/Proyect/Lenguaje/motor
